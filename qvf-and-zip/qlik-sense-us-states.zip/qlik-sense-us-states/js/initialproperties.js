/*global define*/
define( [], function () {
    'use strict';
    return {
        qHyperCubeDef: {
            qDimensions: [],
            qMeasures: [],
            qInitialDataFetch: [
                {
                    qWidth: 3,
                    qHeight: 100
                }
            ]
        }
    };
} );